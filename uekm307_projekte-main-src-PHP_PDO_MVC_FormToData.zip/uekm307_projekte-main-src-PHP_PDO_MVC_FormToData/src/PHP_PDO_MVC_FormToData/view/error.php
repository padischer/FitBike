<?php include('header.php') ?>
    <h2>Error</h2>
    <br>
    <p><?= $error_message ?></p>
    <br>
    <p><a href=".">Back to Request Forms</a></p>
<?php include('footer.php') ?>