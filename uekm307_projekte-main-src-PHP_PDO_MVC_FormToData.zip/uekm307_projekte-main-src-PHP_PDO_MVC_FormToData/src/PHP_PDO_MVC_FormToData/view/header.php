<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MVC with Functions</title>
    <link rel='stylesheet' href="view/css/main.css">
</head>
<body>
<main>
    <header>
        <h1>MVC with Functions</h1>
    </header>
